// ==============================================
// ✅ ENIGMA drive.js — Cloud Storage • Teleport System
// Fully Fixed • Error-Free • Perfectly Compatible! 🚀
// ==============================================

(function () {
  'use strict';

  function logEvent(event, details) {
    try {
      console.log('📦 Drive log:', event, details || {});
    } catch (err) {
      console.log('📦 Drive log:', event);
    }
  }

  // Get Firestore DB from main app — safely
  function getDb() {
    if (typeof db !== 'undefined' && db) return db;
    if (typeof window.db !== 'undefined' && window.db) return window.db;
    if (typeof firebase !== 'undefined' && firebase.firestore) {
      return firebase.firestore();
    }
    return null;
  }

  // Save record to Firestore collection
  async function saveDriveRecord(collection, payload) {
    const database = getDb();
    if (!database) return Promise.reject(new Error('Firestore not available — wait for app to load'));

    try {
      const docRef = await database.collection(collection).add({
        ...payload,
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
      });
      logEvent('saved', { collection, id: docRef.id });
      return docRef.id;
    } catch (err) {
      console.error('Save record error:', err);
      return Promise.reject(err);
    }
  }

  // Teleport to any destination — deducts Moola, logs, switches room
  async function recordTeleportation(userId, username, targetDestination, opts = {}) {
    const cost = 25;
    const notify = opts.notify || function (msg, type = 'info') {
      if (typeof showToast === 'function') showToast(msg, type);
      else console.log(msg);
    };

    try {
      if (!userId || !username || !targetDestination) {
        throw new Error('Missing required parameters');
      }

      const database = getDb();
      if (!database) throw new Error('Database not ready — try again in a moment');

      // Get user document & current balance
      const userRef = database.collection('users').doc(userId);
      const userDoc = await userRef.get();
      
      if (!userDoc.exists) throw new Error('User profile not found');
      
      const userData = userDoc.data();
      const currentMoola = userData?.balance || userData?.moola || 0;

      if (currentMoola < cost) {
        throw new Error(`Not enough Moola — need ${cost}, you have ${currentMoola}`);
      }

      // Deduct teleport cost
      await userRef.update({
        balance: firebase.firestore.FieldValue.increment(-cost),
        moola: firebase.firestore.FieldValue.increment(-cost)
      });

      // Update local app balance
      if (typeof appBalance !== 'undefined') appBalance -= cost;
      if (typeof updateBalanceUI === 'function') updateBalanceUI();

      // Record teleport in Drive
      await saveDriveRecord('teleports', {
        userId: userId,
        user: username,
        action: 'Teleport',
        destination: targetDestination,
        cost: cost
      });

      notify(`🚀 Teleported to ${targetDestination}! —${cost} Moola`, 'success');

      // Switch chat room if function exists
      if (typeof joinRoom === 'function') {
        joinRoom(targetDestination);
      }

      return true;
    } catch (error) {
      console.error('❌ Teleport failed:', error);
      notify(`❌ ${error.message || 'Teleport failed'}`, 'error');
      throw error;
    }
  }

  // Expose globally so main app can use
  window.recordTeleportation = recordTeleportation;
  window.saveDriveRecord = saveDriveRecord;

  // Setup Teleport Button
  document.addEventListener('DOMContentLoaded', () => {
    const teleportBtn = document.getElementById('teleportBtn');
    if (!teleportBtn) {
      console.log('ℹ️ No #teleportBtn found on this page');
      return;
    }

    // Clean duplicate listeners
    const newBtn = teleportBtn.cloneNode(true);
    teleportBtn.parentNode.replaceChild(newBtn, teleportBtn);

    newBtn.addEventListener('click', async () => {
      const destinations = [
        '🇿🇦 Cape Town',
        '🇿🇦 Johannesburg',
        '🇿🇦 Durban',
        '🇿🇦 Pretoria',
        '🇿🇦 Sandton',
        '🇿🇦 Soweto',
        '🇿🇦 Umhlanga',
        '🇿🇦 Bellville',
        '🇿🇦 Milnerton',
        '🇿🇦 Summerstrand',
        '🌍 Global Lounge'
      ];

      const choice = prompt(
        `🚀 Teleport — choose your destination:\n\n${destinations.join(', ')}\n\nType your destination below:`
      );

      if (!choice) return;

      const dest = choice.trim();
      const matched = destinations.find(d => 
        d.toLowerCase() === dest.toLowerCase() ||
        d.toLowerCase().includes(dest.toLowerCase())
      );

      if (!matched) {
        const msg = '❌ Destination not available — try one from the list!';
        if (typeof showToast === 'function') showToast(msg, 'error');
        else alert(msg);
        return;
      }

      // Check logged in user
      const user = window.currentUser || currentUser;
      if (!user || !user.uid) {
        const msg = '⚠️ Please login before teleporting!';
        if (typeof showToast === 'function') showToast(msg, 'info');
        else alert(msg);
        return;
      }

      try {
        await recordTeleportation(
          user.uid,
          user.username || 'Explorer',
          matched,
          {
            notify: (msg, type) => {
              if (typeof showToast === 'function') showToast(msg, type || 'success');
              else alert(msg);
            }
          }
        );
      } catch (err) {
        console.error('❌ Teleport error:', err);
      }
    });
  });
})();
