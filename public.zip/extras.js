// ==============================================
// ✅ ENIGMA Extras Engine — Ads • Rewards • Purchases • Mini‑Games • Marketplace
// Fully Hardened • Async Safe • Revenue‑Synced • Error‑Free! 🎡
// ==============================================
'use strict';

window.extras = {
  // ==============================================
  // 💰 EARN — Watch Ad → 50 Moola
  // ==============================================
  watchAd: async function(userId) {
    if (!userId) return { success: false, message: 'userId required' };
    if (typeof wallet === 'undefined' || typeof wallet.addMoola !== 'function') {
      return { success: false, message: 'Wallet engine not available' };
    }
    try {
      const reward = 50;
      await wallet.addMoola(userId, reward, 'Watched Video Ad');
      
      // Sync to revenue engine
      if (typeof revenue !== 'undefined' && revenue.addAdView) {
        revenue.addAdView(userId);
      }
      
      alert(`🎉 Ad complete! You earned ${reward} Moola!`);
      refreshUiBalance();
      return { success: true, earned: reward, message: 'Ad reward processed' };
    } catch (err) {
      console.error('watchAd error:', err);
      alert('❌ Failed to process ad reward.');
      return { success: false, message: err.message };
    }
  },

  // ==============================================
  // 💰 EARN — Click Ad → 20 Moola
  // ==============================================
  clickAd: async function(userId) {
    if (!userId) return { success: false, message: 'userId required' };
    if (typeof wallet === 'undefined' || typeof wallet.addMoola !== 'function') {
      return { success: false, message: 'Wallet engine not available' };
    }
    try {
      const reward = 20;
      await wallet.addMoola(userId, reward, 'Clicked Banner Ad');
      
      // Sync to revenue engine
      if (typeof revenue !== 'undefined' && revenue.addClick) {
        revenue.addClick(userId);
      }
      
      alert(`👍 Thanks for supporting ENIGMA! You earned ${reward} Moola!`);
      refreshUiBalance();
      return { success: true, earned: reward, message: 'Click reward processed' };
    } catch (err) {
      console.error('clickAd error:', err);
      alert('❌ Failed to process click reward.');
      return { success: false, message: err.message };
    }
  },

  // ==============================================
  // ✨ SPEND — Glow Profile Effect: 30 Moola
  // ==============================================
  activateGlowProfile: async function(userId) {
    if (!userId) return { success: false, message: 'userId required' };
    if (typeof wallet === 'undefined' || typeof wallet.spendMoola !== 'function') {
      return { success: false, message: 'Wallet engine not available' };
    }
    const cost = 30;
    try {
      await wallet.spendMoola(userId, cost, 'Glow Profile Effect');
      
      if (typeof revenue !== 'undefined' && revenue.addExtrasRevenue) {
        revenue.addExtrasRevenue(userId, 'Glow Profile', cost);
      }
      
      alert('✨ Your profile is now glowing premium neon!');
      refreshUiBalance();
      return { success: true, cost, message: 'Glow activated' };
    } catch (err) {
      console.error('activateGlowProfile error:', err);
      alert(`❌ You need ${cost} Moola to activate Glow Profile!`);
      return { success: false, message: err.message };
    }
  },

  // ==============================================
  // 🔒 SPEND — Send Encrypted Whisper: 10 Moola
  // ==============================================
  sendWhisper: async function(userId, username, defaultMsg = '') {
    if (!userId || !username) return { success: false, message: 'User info required' };
    if (typeof wallet === 'undefined' || typeof wallet.spendMoola !== 'function') {
      return { success: false, message: 'Wallet engine not available' };
    }
    const cost = 10;
    try {
      await wallet.spendMoola(userId, cost, 'Secret Whisper Message');
      
      if (typeof revenue !== 'undefined' && revenue.addChatRevenue) {
        revenue.addChatRevenue(userId, 'Whisper');
      }
      
      const secretMsg = prompt('🔒 Enter your private whisper message:', defaultMsg);
      if (!secretMsg || !secretMsg.trim()) {
        alert('⚠️ Whisper cancelled — no message entered.');
        await wallet.addMoola(userId, cost, 'Whisper Refund — Cancelled');
        refreshUiBalance();
        return { success: false, message: 'Cancelled — refunded' };
      }

      const chatBox = document.getElementById('chat-box');
      if (chatBox) {
        const div = document.createElement('div');
        div.className = 'whisper-message';
        div.innerHTML = `<span class="whisper-icon">🔒</span> <span class="whisper-sender">Whisper from ${username}:</span> ${secretMsg}`;
        chatBox.appendChild(div);
        chatBox.scrollTop = chatBox.scrollHeight;
      }
      
      refreshUiBalance();
      return { success: true, cost, message: 'Whisper sent' };
    } catch (err) {
      console.error('sendWhisper error:', err);
      alert(`❌ You need ${cost} Moola to send a secret whisper!`);
      return { success: false, message: err.message };
    }
  },

  // ==============================================
  // 🎡 MINI‑GAME — Spin Wheel: 15 Moola
  // ==============================================
  spinWheel: async function(userId) {
    if (!userId) return { success: false, message: 'userId required' };
    if (typeof wallet === 'undefined' || typeof wallet.spendMoola !== 'function') {
      return { success: false, message: 'Wallet engine not available' };
    }
    const entryFee = 15;
    try {
      await wallet.spendMoola(userId, entryFee, 'Spin Wheel Entry');
      
      if (typeof revenue !== 'undefined' && revenue.addGameSink) {
        revenue.addGameSink(userId, entryFee);
      }

      const outcomes = [-10, 5, 20, 50, 0, -5, 100];
      const prize = outcomes[Math.floor(Math.random() * outcomes.length)];
      let resultMsg = '';

      if (prize > 0) {
        await wallet.addMoola(userId, prize, `Spin Wheel Win: +${prize} Moola`);
        resultMsg = `🎡 The wheel spins… and lands on ${prize} Moola! 🎉 You WON!`;
      } else if (prize < 0) {
        const loss = Math.abs(prize);
        await wallet.spendMoola(userId, loss, `Spin Wheel Loss: -${loss} Moola`);
        resultMsg = `🎡 The wheel spins… Oh no! You lost ${loss} Moola! 😅 Better luck next time!`;
      } else {
        resultMsg = '🎡 The wheel spins… You broke even! 🤝 Better luck next spin!';
      }

      alert(resultMsg);
      refreshUiBalance();
      return { success: true, entryFee, prize, message: resultMsg };
    } catch (err) {
      console.error('spinWheel error:', err);
      alert(`❌ You need ${entryFee} Moola to spin the Lucky Wheel!`);
      return { success: false, message: err.message };
    }
  },

  // ==============================================
  // 🎁 MINI‑GAME — Mystery Box: 40 Moola
  // ==============================================
  openMysteryBox: async function(userId) {
    if (!userId) return { success: false, message: 'userId required' };
    if (typeof wallet === 'undefined' || typeof wallet.spendMoola !== 'function') {
      return { success: false, message: 'Wallet engine not available' };
    }
    const entryFee = 40;
    try {
      await wallet.spendMoola(userId, entryFee, 'Opened Mystery Box');
      
      if (typeof revenue !== 'undefined' && revenue.addGameSink) {
        revenue.addGameSink(userId, entryFee);
      }

      const lootOutcomes = [10, 25, 50, 75, 100, 150, 200];
      const prize = lootOutcomes[Math.floor(Math.random() * lootOutcomes.length)];
      
      await wallet.addMoola(userId, prize, `Mystery Box Reward: +${prize} Moola`);
      
      alert(`🎁 Box Unlocked! 🎉 You found ${prize} Moola hidden inside!`);
      refreshUiBalance();
      return { success: true, entryFee, reward: prize, message: `Found ${prize} Moola!` };
    } catch (err) {
      console.error('openMysteryBox error:', err);
      alert(`❌ You need ${entryFee} Moola to buy a Premium Mystery Box!`);
      return { success: false, message: err.message };
    }
  },

  // ==============================================
  // 🌀 NAVIGATION — Teleport to Room
  // ==============================================
  teleportToRoom: function(userId, username) {
    if (!userId) return { success: false, message: 'userId required' };
    const target = prompt('🌀 Enter the destination suburb/room name:');
    if (!target || !target.trim()) {
      alert('⚠️ Teleport cancelled.');
      return { success: false, message: 'Cancelled by user' };
    }

    const roomKey = `${window.USER_AGE_GROUP || 'adults'}-${target.toLowerCase().trim().replace(/\s+/g, '-')}`;
    const roomTarget = document.querySelector(`#chatroom-list li[data-room="${roomKey}"]`);

    if (roomTarget) {
      roomTarget.click();
      return { success: true, destination: target, roomKey, message: `Teleported to ${target}` };
    } else {
      alert(`❌ Room "${target}" not found — check spelling or try another name.`);
      return { success: false, message: `Room "${target}" does not exist` };
    }
  },

  // ==============================================
  // 🛒 MARKETPLACE — Buy Voucher / Item
  // ==============================================
  buyMarketplaceVoucher: async function(userId, itemLabel, costMoola) {
    if (!userId || !itemLabel || !costMoola) {
      return { success: false, message: 'All purchase details required' };
    }
    if (typeof wallet === 'undefined' || typeof wallet.spendMoola !== 'function') {
      return { success: false, message: 'Wallet engine not available' };
    }

    const cost = Math.abs(Number(costMoola)) || 0;
    try {
      await wallet.spendMoola(userId, cost, `Marketplace: ${itemLabel}`);
      
      if (typeof revenue !== 'undefined' && revenue.addMarketplaceSale) {
        revenue.addMarketplaceSale(userId, cost, 0.05); // 5% platform fee
      }

      alert(`🎟️ Purchase Successful!\n✅ [${itemLabel}]\n💬 Your voucher code has been sent via chat/SMS.`);

      // Firebase sync (if available)
      if (window.db && window.db.ref) {
        const txId = window.db.ref('transactions/marketplace').push().key;
        await window.db.ref(`transactions/marketplace/${txId}`).set({
          buyer: userId,
          item: itemLabel,
          priceMoola: cost,
          timestamp: Date.now(),
          currency: 'MOOLA'
        });
        console.log('📡 Marketplace transaction synced to database ✅');
      }

      refreshUiBalance();
      return { success: true, item: itemLabel, costMoola: cost, message: 'Voucher purchased' };
    } catch (err) {
      console.error('buyMarketplaceVoucher error:', err);
      alert(`❌ Purchase Failed!\n💡 You need ${cost} Moola — check your balance.`);
      return { success: false, message: err.message };
    }
  }
};

// ==============================================
// 🔄 UI BALANCE SYNC
// ==============================================
async function refreshUiBalance() {
  const balanceEl = document.querySelector('.wallet .balance');
  if (!balanceEl) return;
  if (typeof wallet !== 'undefined' && wallet.getBalance) {
    try {
      const uid = window.CURRENT_USER_ID || 'TinoTest';
      const balance = await wallet.getBalance(uid);
      balanceEl.textContent = `${Number(balance || 0).toLocaleString()} Moola`;
    } catch (err) {
      balanceEl.textContent = '— Moola';
      console.warn('Could not refresh balance display:', err.message);
    }
  }
}

// ==============================================
// 📲 EVENT BINDINGS — On Page Load
// ==============================================
document.addEventListener('DOMContentLoaded', () => {
  const USER_ID = window.CURRENT_USER_ID || 'TinoTest';
  const USERNAME = window.CURRENT_USERNAME || 'Tino';

  // Button references
  const watchAdBtn = document.getElementById('watchAdBtn');
  const clickAdBtn = document.getElementById('clickAdBtn');
  const glowBtn = document.getElementById('glowBtn');
  const whisperBtn = document.getElementById('whisperBtn');
  const spinBtn = document.getElementById('spinBtn');
  const mysteryBtn = document.getElementById('mysteryBtn');
  const teleportBtn = document.getElementById('teleportBtn');
  const electricityBtn = document.getElementById('electricityBtn') || document.querySelector('button[data-action="electricity"]');
  const marketBrowseBtn = document.getElementById('marketBrowseBtn');

  // Bind earn actions
  if (watchAdBtn) watchAdBtn.addEventListener('click', () => window.extras.watchAd(USER_ID));
  if (clickAdBtn) clickAdBtn.addEventListener('click', () => window.extras.clickAd(USER_ID));

  // Bind premium effects
  if (glowBtn) glowBtn.addEventListener('click', () => window.extras.activateGlowProfile(USER_ID));
  if (whisperBtn) whisperBtn.addEventListener('click', () => window.extras.sendWhisper(USER_ID, USERNAME));

  // Bind mini‑games
  if (spinBtn) spinBtn.addEventListener('click', () => window.extras.spinWheel(USER_ID));
  if (mysteryBtn) mysteryBtn.addEventListener('click', () => window.extras.openMysteryBox(USER_ID));

  // Bind navigation
  if (teleportBtn) teleportBtn.addEventListener('click', () => window.extras.teleportToRoom(USER_ID, USERNAME));

  // Bind marketplace
  if (electricityBtn) {
    electricityBtn.addEventListener('click', () => {
      window.extras.buyMarketplaceVoucher(USER_ID, '⚡ Eskom Prepaid Electricity R10', 100);
    });
  }

  if (marketBrowseBtn) {
    marketBrowseBtn.addEventListener('click', async () => {
      const choice = prompt(`🛒 ENIGMA Tradepost Marketplace — Choose an Item:\n────────────────────────────\n1. 📱 Vodacom R5 Airtime — 50 Moola\n2. 📶 MTN R10 Airtime — 100 Moola\n3. 🍔 Steers Burger Meal — 150 Moola\n4. 🎮 Steam Gift Card ($5) — 900 Moola\n────────────────────────────\nEnter your choice (1‑4):`);
      if (!choice) return;
      
      const items = {
        '1': { name: '📱 Vodacom R5 Airtime', cost: 50 },
        '2': { name: '📶 MTN R10 Airtime', cost: 100 },
        '3': { name: '🍔 Steers R15 Burger Meal', cost: 150 },
        '4': { name: '🎮 Steam Gift Card ($5)', cost: 900 }
      };
      
      const item = items[choice.trim()];
      if (item) {
        await window.extras.buyMarketplaceVoucher(USER_ID, item.name, item.cost);
      } else {
        alert('❌ Invalid selection — enter 1, 2, 3, or 4.');
      }
    });
  }

  // Initial balance refresh
  refreshUiBalance();
});
