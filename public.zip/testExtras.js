// ==============================================
// ✅ ENIGMA Extras Test Suite — Browser Version
// Full Async Test Runner • Balance Tracking • Error Reporting
// Fully Hardened • Reliable • Clear Output! 🧪
// ==============================================
'use strict';

(async () => {
  const testUserId = 'TinoTest';
  const testUsername = 'Tino';

  console.log('🧪 === ENIGMA EXTRAS TEST SUITE STARTED ===');
  console.log(`👤 Testing as user: ${testUserId}`);

  // --- Guard checks ---
  if (typeof wallet === 'undefined') {
    console.error('❌ ERROR: wallet not found — load wallet.js first!');
    return;
  }
  if (typeof extras === 'undefined') {
    console.error('❌ ERROR: extras not found — load extras.js first!');
    return;
  }

  // --- Initialize wallet & starting balance ---
  try {
    if (typeof wallet.createWallet === 'function') {
      wallet.createWallet(testUserId);
      console.log('✅ Wallet created');
    }

    await wallet.addMoola(testUserId, 200, '🧪 Test initial deposit — 200 Moola');
    const initialBalance = await wallet.getBalance(testUserId);
    console.log(`💰 Initial Balance: ${initialBalance} Moola`);
  } catch (err) {
    console.error('❌ Failed to initialize wallet:', err);
    return;
  }

  // --- Helper: log separator + balance ---
  async function logState(label) {
    const balance = await wallet.getBalance(testUserId);
    console.log(`📊 ${label} — Current Balance: ${balance} Moola`);
    console.log('─'.repeat(60));
  }

  await logState('After Setup');

  // ==============================================
  // ✨ TEST: Glow Profile — 30 Moola
  // ==============================================
  console.log('\n🧪 TEST 1: activateGlowProfile (30 Moola)');
  try {
    const result = await extras.activateGlowProfile(testUserId);
    console.log('✨ Glow Profile Result:', result);
    if (result.success) console.log('✅ Glow Profile — PASSED');
    else console.warn('⚠️ Glow Profile — returned success:false');
  } catch (err) {
    console.error('❌ Glow Profile — FAILED:', err.message);
  }
  await logState('After Glow Profile');

  // ==============================================
  // 🔒 TEST: Send Whisper — 10 Moola
  // ==============================================
  console.log('\n🧪 TEST 2: sendWhisper (10 Moola)');
  try {
    const result = await extras.sendWhisper(testUserId, testUsername, '🤫 Secret test message from Test Suite!');
    console.log('🤫 Whisper Result:', result);
    if (result.success) console.log('✅ Whisper — PASSED');
    else console.warn('⚠️ Whisper — returned success:false');
  } catch (err) {
    console.error('❌ Whisper — FAILED:', err.message);
  }
  await logState('After Whisper');

  // ==============================================
  // 🎁 TEST: Mystery Box — 40 Moola
  // ==============================================
  console.log('\n🧪 TEST 3: openMysteryBox (40 Moola)');
  try {
    const result = await extras.openMysteryBox(testUserId);
    console.log('🎁 Mystery Box Result:', result);
    if (result.success) {
      console.log(`✅ Mystery Box — PASSED | Reward: ${result.reward} Moola`);
    } else {
      console.warn('⚠️ Mystery Box — returned success:false');
    }
  } catch (err) {
    console.error('❌ Mystery Box — FAILED:', err.message);
  }
  await logState('After Mystery Box');

  // ==============================================
  // 🎡 TEST: Spin Wheel — 15 Moola
  // ==============================================
  console.log('\n🧪 TEST 4: spinWheel (15 Moola)');
  try {
    const result = await extras.spinWheel(testUserId);
    console.log('🎡 Spin Wheel Result:', result);
    if (result.success) {
      const outcome = result.prize > 0 ? `WON ${result.prize} Moola 🎉` :
                      result.prize < 0 ? `LOST ${Math.abs(result.prize)} Moola 😅` : 'Broke Even 🤝';
      console.log(`✅ Spin Wheel — PASSED | Outcome: ${outcome}`);
    } else {
      console.warn('⚠️ Spin Wheel — returned success:false');
    }
  } catch (err) {
    console.error('❌ Spin Wheel — FAILED:', err.message);
  }
  await logState('After Spin Wheel');

  // ==============================================
  // 📺 TEST: Watch Ad — Earn 50 Moola
  // ==============================================
  console.log('\n🧪 TEST 5: watchAd (+50 Moola)');
  try {
    const result = await extras.watchAd(testUserId);
    console.log('📺 Watch Ad Result:', result);
    if (result.success) console.log('✅ Watch Ad — PASSED | +50 Moola earned!');
    else console.warn('⚠️ Watch Ad — returned success:false');
  } catch (err) {
    console.error('❌ Watch Ad — FAILED:', err.message);
  }
  await logState('After Watch Ad');

  // ==============================================
  // 🖱️ TEST: Click Ad — Earn 20 Moola
  // ==============================================
  console.log('\n🧪 TEST 6: clickAd (+20 Moola)');
  try {
    const result = await extras.clickAd(testUserId);
    console.log('🖱️ Click Ad Result:', result);
    if (result.success) console.log('✅ Click Ad — PASSED | +20 Moola earned!');
    else console.warn('⚠️ Click Ad — returned success:false');
  } catch (err) {
    console.error('❌ Click Ad — FAILED:', err.message);
  }
  await logState('After Click Ad');

  // ==============================================
  // 🛒 TEST: Marketplace Purchase — 50 Moola
  // ==============================================
  console.log('\n🧪 TEST 7: buyMarketplaceVoucher (50 Moola — Vodacom Airtime)');
  try {
    const result = await extras.buyMarketplaceVoucher(testUserId, '📱 Vodacom R5 Airtime (Test)', 50);
    console.log('🛒 Marketplace Voucher Result:', result);
    if (result.success) console.log('✅ Marketplace Purchase — PASSED');
    else console.warn('⚠️ Marketplace Purchase — returned success:false');
  } catch (err) {
    console.error('❌ Marketplace Purchase — FAILED:', err.message);
  }
  await logState('After Marketplace Purchase');

  // ==============================================
  // 📊 FINAL SUMMARY
  // ==============================================
  const finalBalance = await wallet.getBalance(testUserId);
  console.log('\n' + '='.repeat(60));
  console.log('🏁 === TEST SUITE COMPLETE ===');
  console.log(`💰 Starting Balance: 200 Moola`);
  console.log(`💰 Final Balance:   ${finalBalance} Moola`);
  console.log(`📊 Net Change:      ${finalBalance - 200} Moola`);
  console.log('='.repeat(60));

})();
