// ==============================================
// ✅ ENIGMA Fare Calculator — Ride Pricing Engine
// 🚗 Calculate • Distance • Time • Base • Surge • Vehicle • Commission • Payout
// Fully Hardened • South African Rates • Production‑Ready! 🇿🇦
// ==============================================

// ==============================================
// ⚙️ PRICING CONFIG — South African Defaults
// All values in ZAR (South African Rand)
// ==============================================
const PRICING = {
  // Base Fare — fixed starting fee
  baseFare: 20.00,           // R20.00 base

  // Per‑Unit Rates
  ratePerKm: 10.00,          // R10.00 per kilometer
  ratePerMinute: 2.00,       // R2.00 per minute of ride time

  // Minimum Fare — never charge less than this
  minimumFare: 35.00,        // R35.00 minimum per ride

  // Commission — ENIGMA platform fee
  commissionRate: 0.20,      // 20% commission on total fare

  // Vehicle Type Multipliers
  vehicleMultipliers: {
    standard: 1.00,
    eco: 0.85,
    suv: 1.30,
    luxury: 1.60,
    van: 1.40,
    bike: 0.70
  },

  // Surge Multiplier Bounds
  surgeMin: 1.00,
  surgeMax: 2.50,

  // Distance thresholds for long‑ride discounts
  longRiseKm: 15,
  longRiseDiscount: 0.10    // 10% off per km beyond 15km
};

// ==============================================
// 🌍 HAVERSINE — Calculate Distance Between Coordinates
// Returns distance in kilometers
// ==============================================
function haversineDistance(lat1, lng1, lat2, lng2) {
  // Validate inputs
  [lat1, lng1, lat2, lng2].forEach(coord => {
    if (typeof coord !== 'number' || !Number.isFinite(coord)) {
      throw new Error('Invalid coordinate: must be a valid number');
    }
  });

  const R = 6371; // Earth radius in km
  const toRad = (deg) => deg * Math.PI / 180;

  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// ==============================================
// 💰 MAIN FARE CALCULATOR
// ==============================================
/**
 * Calculate complete ride fare breakdown
 * @param {number} pickupLat - Pickup latitude
 * @param {number} pickupLng - Pickup longitude
 * @param {number} dropLat - Dropoff latitude
 * @param {number} dropLng - Dropoff longitude
 * @param {number} durationMinutes - Estimated/actual ride duration
 * @param {string} [vehicleType='standard'] - Vehicle tier
 * @param {number} [surgeMultiplier=1.0] - Surge/peak pricing multiplier
 * @param {boolean} [applyMinFare=true] - Enforce minimum fare
 * @returns {Object} fare breakdown
 */
function calculateFare(
  pickupLat, pickupLng, dropLat, dropLng, durationMinutes,
  vehicleType = 'standard', surgeMultiplier = 1.0, applyMinFare = true
) {
  // 🛡️ Input Validation
  if (typeof durationMinutes !== 'number' || durationMinutes < 0) {
    throw new Error('Duration must be a non‑negative number');
  }

  const distanceKm = haversineDistance(pickupLat, pickupLng, dropLat, dropLng);

  if (distanceKm <= 0) {
    throw new Error('Pickup and drop‑off locations cannot be the same');
  }

  // Normalize inputs
  const vehType = PRICING.vehicleMultipliers.hasOwnProperty(vehicleType)
    ? vehicleType : 'standard';
  const vMultiplier = PRICING.vehicleMultipliers[vehType];

  const surge = Math.max(PRICING.surgeMin, Math.min(PRICING.surgeMax, Number(surgeMultiplier) || 1.0));

  // 📏 Distance Fare — apply long‑ride discount beyond threshold
  let distanceFare = distanceKm * PRICING.ratePerKm;
  if (distanceKm > PRICING.longRiseKm) {
    const discountKm = distanceKm - PRICING.longRiseKm;
    distanceFare -= discountKm * PRICING.ratePerKm * PRICING.longRiseDiscount;
  }

  // 🧮 Build Fare Components
  const baseComponent = PRICING.baseFare;
  const distanceComponent = distanceFare;
  const timeComponent = durationMinutes * PRICING.ratePerMinute;

  let subtotal = baseComponent + distanceComponent + timeComponent;

  // Apply vehicle tier multiplier
  subtotal *= vMultiplier;

  // Apply surge pricing
  subtotal *= surge;

  // Apply minimum fare floor
  let fare = subtotal;
  if (applyMinFare && fare < PRICING.minimumFare) {
    fare = PRICING.minimumFare;
  }

  // 💵 Commission & Payout Split
  const commission = fare * PRICING.commissionRate;
  const payoutAmount = fare - commission;

  // 🎯 Return formatted breakdown (2 decimal places for currency)
  return {
    fare: Math.round(fare * 100) / 100,
    commission: Math.round(commission * 100) / 100,
    payoutAmount: Math.round(payoutAmount * 100) / 100,
    distanceKm: Math.round(distanceKm * 10) / 10,
    durationMinutes: Math.round(durationMinutes * 10) / 10,

    // Detailed breakdown for display
    breakdown: {
      baseFare: Math.round(baseComponent * 100) / 100,
      distanceFare: Math.round(distanceComponent * 100) / 100,
      timeFare: Math.round(timeComponent * 100) / 100,
      vehicleMultiplier: vMultiplier,
      vehicleType: vehType,
      surgeMultiplier: Math.round(surge * 100) / 100,
      subtotalBeforeMin: Math.round(subtotal * 100) / 100,
      minimumFareApplied: applyMinFare && subtotal < PRICING.minimumFare,
      minimumFareThreshold: PRICING.minimumFare
    }
  };
}

// ==============================================
// 🔁 ESTIMATE vs ACTUAL — Two Convenience Aliases
// ==============================================

/** Estimated fare (for before‑ride display) */
function estimateFare(pickupLat, pickupLng, dropLat, dropLng, durationMinutes, vehicleType, surgeMultiplier) {
  return calculateFare(pickupLat, pickupLng, dropLat, dropLng, durationMinutes, vehicleType, surgeMultiplier, true);
}

/** Final actual fare (after ride completes — can skip min fare if needed) */
function finalizeFare(pickupLat, pickupLng, dropLat, dropLng, actualDurationMinutes, vehicleType, surgeMultiplier) {
  return calculateFare(pickupLat, pickupLng, dropLat, dropLng, actualDurationMinutes, vehicleType, surgeMultiplier, false);
}

// ==============================================
// 📤 EXPORT
// ==============================================
module.exports = {
  calculateFare,
  estimateFare,
  finalizeFare,
  haversineDistance,
  PRICING  // Expose config for admin adjustments
};
