// ==============================================
// ✅ ENIGMA Revenue Engine — Admin Financial Tracking
// Ad Views • Clicks • Marketplace • Games • Karaoke • Chat • Extras • Cash‑Outs • Sponsors
// Multi‑Currency • Auto‑Reports • Persistent • Error‑Free! 📊
// ==============================================
'use strict';

const fs = require("fs");
const path = require("path");

// ==============================================
// ⚙️ CONSTANTS — Matches ENIGMA Economy Blueprint
// ==============================================
const MOOLA_TO_ZAR_RATE = 0.10;       // 1 Moola = R0.10 (R10.00 = 100 Moola)
const MOOLA_TO_USD_RATE = 0.055;       // 1 Moola = $0.055
const MOOLA_TO_EUR_RATE = 0.050;       // 1 Moola = €0.05
const MOOLA_TO_GBP_RATE = 0.043;       // 1 Moola = £0.043

const AD_VIEW_RATE_ZAR = 0.05;         // R0.05 per ad view
const AD_CLICK_RATE_ZAR = 0.25;        // R0.25 per ad click
const PREMIUM_CHAT_COST_MOOLA = 2;     // 2 Moola per premium message

const MAX_HISTORY = 10000;
const TRIM_THRESHOLD = 12000;

// ==============================================
// 📈 REVENUE BUCKETS
// ==============================================
function emptyRevenueBucket() {
  return {
    adViews: 0, clicks: 0, marketplaceFees: 0, gameSinks: 0,
    karaokeTaxes: 0, chatRevenue: 0, extrasRevenue: 0, cashouts: 0,
    totalZAR: 0, totalUSD: 0, totalEUR: 0, totalGBP: 0,
    grossMoola: 0, netZAR: 0
  };
}

let dailyRevenue = emptyRevenueBucket();
let weeklyRevenue = emptyRevenueBucket();
let transactionHistory = [];
let sponsorRevenue = [];

const logFile = path.join(__dirname, "revenue_log.txt");
const dataFile = path.join(__dirname, "revenue_data.json");

// ==============================================
// 🔧 UTILITIES
// ==============================================
function round2(num) {
  return Math.round((Number(num) || 0) * 100) / 100;
}

function convertMoola(moola, currency = 'ZAR') {
  const val = Number(moola) || 0;
  switch ((currency || 'ZAR').toUpperCase()) {
    case 'USD': return round2(val * MOOLA_TO_USD_RATE);
    case 'EUR': return round2(val * MOOLA_TO_EUR_RATE);
    case 'GBP': return round2(val * MOOLA_TO_GBP_RATE);
    default: return round2(val * MOOLA_TO_ZAR_RATE);
  }
}

function logToFile(message) {
  try {
    const ts = new Date().toISOString();
    fs.appendFileSync(logFile, `[${ts}] ${message}\n`);
  } catch (err) {
    console.warn('⚠️ Revenue log failed:', err.message);
  }
}

function saveToFile() {
  try {
    const data = {
      dailyRevenue, weeklyRevenue, transactionHistory, sponsorRevenue,
      lastUpdated: new Date().toISOString(),
      rates: { MOOLA_TO_ZAR_RATE, MOOLA_TO_USD_RATE, MOOLA_TO_EUR_RATE, MOOLA_TO_GBP_RATE }
    };
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
  } catch (err) {
    console.warn('⚠️ Revenue save failed:', err.message);
  }
}

function loadFromFile() {
  try {
    if (!fs.existsSync(dataFile)) return;
    const loaded = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
    if (loaded.dailyRevenue) dailyRevenue = { ...emptyRevenueBucket(), ...loaded.dailyRevenue };
    if (loaded.weeklyRevenue) weeklyRevenue = { ...emptyRevenueBucket(), ...loaded.weeklyRevenue };
    if (Array.isArray(loaded.transactionHistory)) transactionHistory = loaded.transactionHistory;
    if (Array.isArray(loaded.sponsorRevenue)) sponsorRevenue = loaded.sponsorRevenue;
    console.log('✅ Revenue data loaded');
  } catch (err) {
    console.warn('⚠️ Revenue load failed:', err.message);
  }
}

function addTransaction(type, userId, amountZAR, details = {}) {
  const tx = {
    type, userId, amountZAR: round2(amountZAR), details,
    timestamp: new Date().toISOString()
  };
  transactionHistory.push(tx);
  if (transactionHistory.length > TRIM_THRESHOLD) {
    transactionHistory = transactionHistory.slice(-MAX_HISTORY);
  }
  logToFile(`${type} | User: ${userId} | R${round2(amountZAR)} | ${JSON.stringify(details)}`);
  saveToFile();
  return tx;
}

function updateBucketTotals(bucket, amountZAR, moolaAmount = 0) {
  bucket.totalZAR = round2((bucket.totalZAR || 0) + amountZAR);
  bucket.totalUSD = round2((bucket.totalUSD || 0) + convertMoola(moolaAmount, 'USD'));
  bucket.totalEUR = round2((bucket.totalEUR || 0) + convertMoola(moolaAmount, 'EUR'));
  bucket.totalGBP = round2((bucket.totalGBP || 0) + convertMoola(moolaAmount, 'GBP'));
  bucket.grossMoola = round2((bucket.grossMoola || 0) + moolaAmount);
  bucket.netZAR = round2(bucket.totalZAR - (bucket.cashouts || 0));
}

// ==============================================
// 💰 REVENUE SOURCES
// ==============================================
function addAdView(userId) {
  const zar = round2(AD_VIEW_RATE_ZAR);
  dailyRevenue.adViews = round2(dailyRevenue.adViews + zar);
  weeklyRevenue.adViews = round2(weeklyRevenue.adViews + zar);
  updateBucketTotals(dailyRevenue, zar, zar / MOOLA_TO_ZAR_RATE);
  updateBucketTotals(weeklyRevenue, zar, zar / MOOLA_TO_ZAR_RATE);
  addTransaction('adView', userId, zar);
  console.log(`📺 Ad View | User: ${userId} | +R${zar}`);
  return zar;
}

function addClick(userId) {
  const zar = round2(AD_CLICK_RATE_ZAR);
  dailyRevenue.clicks = round2(dailyRevenue.clicks + zar);
  weeklyRevenue.clicks = round2(weeklyRevenue.clicks + zar);
  updateBucketTotals(dailyRevenue, zar, zar / MOOLA_TO_ZAR_RATE);
  updateBucketTotals(weeklyRevenue, zar, zar / MOOLA_TO_ZAR_RATE);
  addTransaction('adClick', userId, zar);
  console.log(`🖱️ Ad Click | User: ${userId} | +R${zar}`);
  return zar;
}

function addMarketplaceSale(userId, itemPriceMoola, feePercentage = 0.05) {
  const moola = Number(itemPriceMoola) || 0;
  const zar = round2(moola * MOOLA_TO_ZAR_RATE);
  const feeZAR = round2(zar * feePercentage);
  dailyRevenue.marketplaceFees = round2(dailyRevenue.marketplaceFees + feeZAR);
  weeklyRevenue.marketplaceFees = round2(weeklyRevenue.marketplaceFees + feeZAR);
  updateBucketTotals(dailyRevenue, feeZAR, moola * feePercentage);
  updateBucketTotals(weeklyRevenue, feeZAR, moola * feePercentage);
  addTransaction('marketplaceFee', userId, feeZAR, { itemPriceMoola, zar, feePercentage });
  console.log(`🏪 Marketplace | User: ${userId} | Item R${zar} | Fee R${feeZAR}`);
  return feeZAR;
}

function addGameSink(userId, feeChargedMoola) {
  const moola = Number(feeChargedMoola) || 0;
  const zar = round2(moola * MOOLA_TO_ZAR_RATE);
  dailyRevenue.gameSinks = round2(dailyRevenue.gameSinks + zar);
  weeklyRevenue.gameSinks = round2(weeklyRevenue.gameSinks + zar);
  updateBucketTotals(dailyRevenue, zar, moola);
  updateBucketTotals(weeklyRevenue, zar, moola);
  addTransaction('gameSink', userId, zar, { feeChargedMoola: moola });
  console.log(`🎮 Game Sink | User: ${userId} | -${moola} Moola = R${zar}`);
  return zar;
}

function addKaraokeTax(userId, tipAmountMoola, taxPercentage = 0.10) {
  const moola = Number(tipAmountMoola) || 0;
  const tipZAR = round2(moola * MOOLA_TO_ZAR_RATE);
  const taxZAR = round2(tipZAR * taxPercentage);
  dailyRevenue.karaokeTaxes = round2(dailyRevenue.karaokeTaxes + taxZAR);
  weeklyRevenue.karaokeTaxes = round2(weeklyRevenue.karaokeTaxes + taxZAR);
  updateBucketTotals(dailyRevenue, taxZAR, moola * taxPercentage);
  updateBucketTotals(weeklyRevenue, taxZAR, moola * taxPercentage);
  addTransaction('karaokeTax', userId, taxZAR, { tipMoola: moola, tipZAR, taxPercentage });
  console.log(`🎤 Karaoke Tax | User: ${userId} | Tip R${tipZAR} | Tax R${taxZAR}`);
  return taxZAR;
}

function addChatRevenue(userId, roomName = 'General') {
  const moola = PREMIUM_CHAT_COST_MOOLA;
  const zar = round2(moola * MOOLA_TO_ZAR_RATE);
  dailyRevenue.chatRevenue = round2(dailyRevenue.chatRevenue + zar);
  weeklyRevenue.chatRevenue = round2(weeklyRevenue.chatRevenue + zar);
  updateBucketTotals(dailyRevenue, zar, moola);
  updateBucketTotals(weeklyRevenue, zar, moola);
  addTransaction('chatRevenue', userId, zar, { roomName, costMoola: moola });
  console.log(`💬 Premium Chat | User: ${userId} @ ${roomName} | R${zar}`);
  return zar;
}

function addExtrasRevenue(userId, extraName = 'Unknown', costMoola = 0) {
  const moola = Number(costMoola) || 0;
  const zar = round2(moola * MOOLA_TO_ZAR_RATE);
  dailyRevenue.extrasRevenue = round2(dailyRevenue.extrasRevenue + zar);
  weeklyRevenue.extrasRevenue = round2(weeklyRevenue.extrasRevenue + zar);
  updateBucketTotals(dailyRevenue, zar, moola);
  updateBucketTotals(weeklyRevenue, zar, moola);
  addTransaction('extrasRevenue', userId, zar, { extraName, costMoola: moola });
  console.log(`✨ Extra | User: ${userId} | ${extraName} | R${zar}`);
  return zar;
}

function addCashout(userId, amountMoola, method = 'EFT') {
  const moola = Number(amountMoola) || 0;
  const zar = round2(moola * MOOLA_TO_ZAR_RATE);
  dailyRevenue.cashouts = round2(dailyRevenue.cashouts + zar);
  weeklyRevenue.cashouts = round2(weeklyRevenue.cashouts + zar);
  dailyRevenue.netZAR = round2(dailyRevenue.totalZAR - dailyRevenue.cashouts);
  weeklyRevenue.netZAR = round2(weeklyRevenue.totalZAR - weeklyRevenue.cashouts);
  addTransaction('cashout', userId, zar, { amountMoola: moola, method });
  console.log(`💸 Cash‑Out | User: ${userId} | ${moola} Moola = R${zar} via ${method}`);
  return zar;
}

function addSponsorRevenue(sponsorName, amountZAR) {
  const zar = round2(Math.abs(Number(amountZAR) || 0));
  const entry = { sponsorName, amountZAR: zar, timestamp: new Date().toISOString() };
  sponsorRevenue.push(entry);
  updateBucketTotals(dailyRevenue, zar, zar / MOOLA_TO_ZAR_RATE);
  updateBucketTotals(weeklyRevenue, zar, zar / MOOLA_TO_ZAR_RATE);
  addTransaction('sponsorRevenue', sponsorName, zar);
  console.log(`🏆 Sponsor | ${sponsorName} | R${zar}`);
  return zar;
}

// ==============================================
// 📊 REPORTING & QUERIES
// ==============================================
function generateDailyReport() {
  const report = {
    ...dailyRevenue,
    generatedAt: new Date().toISOString(),
    currencyRates: { ZAR: MOOLA_TO_ZAR_RATE, USD: MOOLA_TO_USD_RATE, EUR: MOOLA_TO_EUR_RATE, GBP: MOOLA_TO_GBP_RATE }
  };
  logToFile(`Daily Report: ${JSON.stringify(report, null, 2)}`);
  console.log("📊 Daily Revenue Report:", report);
  return report;
}

function generateWeeklyReport() {
  const report = {
    ...weeklyRevenue,
    generatedAt: new Date().toISOString(),
    currencyRates: { ZAR: MOOLA_TO_ZAR_RATE, USD: MOOLA_TO_USD_RATE, EUR: MOOLA_TO_EUR_RATE, GBP: MOOLA_TO_GBP_RATE }
  };
  logToFile(`Weekly Report: ${JSON.stringify(report, null, 2)}`);
  console.log("📊 Weekly Revenue Report:", report);
  return report;
}

function getRevenueSummary() {
  return {
    daily: { ...dailyRevenue },
    weekly: { ...weeklyRevenue },
    totals: {
      totalTransactions: transactionHistory.length,
      totalSponsors: sponsorRevenue.length,
      allTimeZAR: round2(transactionHistory.reduce((s, t) => s + (t.amountZAR || 0), 0)),
      cashoutsTotalZAR: round2(transactionHistory.filter(t => t.type === 'cashout').reduce((s, t) => s + (t.amountZAR || 0), 0))
    },
    sponsorRevenue: [...sponsorRevenue],
    lastUpdated: new Date().toISOString()
  };
}

function getTransactionHistory(limit = 100, type = null, userId = null) {
  let filtered = transactionHistory;
  if (type) filtered = filtered.filter(tx => tx.type === type);
  if (userId) filtered = filtered.filter(tx => tx.userId === userId);
  return filtered.slice(-Math.abs(limit));
}

// ==============================================
// 🔄 RESETS & SCHEDULING
// ==============================================
function resetDailyRevenue() {
  const report = generateDailyReport();
  dailyRevenue = emptyRevenueBucket();
  logToFile("=== DAILY REVENUE RESET ===");
  console.log("🔄 Daily revenue reset");
  return report;
}

function resetWeeklyRevenue() {
  const report = generateWeeklyReport();
  weeklyRevenue = emptyRevenueBucket();
  logToFile("=== WEEKLY REVENUE RESET ===");
  console.log("🔄 Weekly revenue reset");
  return report;
}

// Smart scheduler — no drift, uses real time
let lastDailyReset = Date.now();
let lastWeeklyReset = Date.now();
const DAY_MS = 24 * 60 * 60 * 1000;
const WEEK_MS = 7 * DAY_MS;

loadFromFile();

setInterval(() => {
  const now = Date.now();
  if (now - lastDailyReset >= DAY_MS) {
    resetDailyRevenue();
    lastDailyReset = now;
  }
  if (now - lastWeeklyReset >= WEEK_MS) {
    resetWeeklyRevenue();
    lastWeeklyReset = now;
  }
  saveToFile();
}, 60 * 60 * 1000);

process.on('SIGINT', () => { saveToFile(); process.exit(); });
process.on('SIGTERM', () => { saveToFile(); process.exit(); });

// ==============================================
// 📤 EXPORTS
// ==============================================
module.exports = {
  MOOLA_TO_ZAR_RATE, MOOLA_TO_USD_RATE, MOOLA_TO_EUR_RATE, MOOLA_TO_GBP_RATE,
  convertMoola, round2,
  addAdView, addClick, addMarketplaceSale, addGameSink, addKaraokeTax,
  addChatRevenue, addExtrasRevenue, addCashout, addSponsorRevenue,
  generateDailyReport, generateWeeklyReport, getRevenueSummary,
  getTransactionHistory, resetDailyRevenue, resetWeeklyRevenue
};
