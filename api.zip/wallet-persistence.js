// ==============================================
// ✅ ENIGMA MongoDB Wallet Persistence — Production Ready
// Schemas • Atomic Operations • Transactions • Full CRUD • Admin Tools
// Fully Hardened • Secure • Error‑Free! 💾
// ==============================================
'use strict';

const mongoose = require('mongoose');

// ==============================================
// 💰 WALLET SCHEMA
// ==============================================
const walletSchema = new mongoose.Schema({
  userId: { 
    type: String, 
    required: [true, 'userId is required'], 
    unique: true,
    index: true,
    trim: true
  },
  balance: { 
    type: Number, 
    default: 100,
    min: [0, 'Balance cannot be negative'],
    validate: {
      validator: Number.isFinite,
      message: 'Balance must be a valid number'
    }
  },
  totalEarned: { type: Number, default: 0, min: 0 },
  totalSpent: { type: Number, default: 0, min: 0 },
  lastTransaction: { type: Date, default: null },
  updatedAt: { type: Date, default: Date.now }
}, { 
  timestamps: true,
  collection: 'wallets',
  versionKey: false
});

// Indexes for fast queries
walletSchema.index({ balance: -1 });
walletSchema.index({ createdAt: -1 });

// ==============================================
// 📜 TRANSACTION SCHEMA
// ==============================================
const transactionSchema = new mongoose.Schema({
  userId: { 
    type: String, 
    required: [true, 'userId is required'],
    index: true,
    trim: true
  },
  type: { 
    type: String, 
    enum: {
      values: ['credit', 'debit', 'conversion', 'transfer'],
      message: 'Invalid transaction type'
    },
    required: true
  },
  amount: { 
    type: Number, 
    required: [true, 'Amount is required'],
    validate: {
      validator: Number.isFinite,
      message: 'Amount must be a valid number'
    }
  },
  description: { type: String, default: '', trim: true, maxlength: 250 },
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  createdAt: { type: Date, default: Date.now, index: true }
}, { 
  timestamps: true,
  collection: 'transactions',
  versionKey: false
});

// Compound indexes for fast history queries
transactionSchema.index({ userId: 1, createdAt: -1 });
transactionSchema.index({ userId: 1, type: 1, createdAt: -1 });

// ==============================================
// 📊 MODELS
// ==============================================
const Wallet = mongoose.models.Wallet || mongoose.model('Wallet', walletSchema);
const Transaction = mongoose.models.Transaction || mongoose.model('Transaction', transactionSchema);

// ==============================================
// 🚀 MONGODB WALLET MANAGER CLASS
// ==============================================
class MongoWalletManager {
  constructor(uri) {
    this.uri = uri || process.env.MONGO_URI || 'mongodb://localhost:27017/enigma';
    this.connected = false;
    this.connection = null;
  }

  async connect() {
    if (this.connected) return true;
    try {
      this.connection = await mongoose.connect(this.uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        serverSelectionTimeoutMS: 5000
      });
      this.connected = true;
      console.log('✅ ENIGMA Wallet: Connected to MongoDB');
      return true;
    } catch (err) {
      console.error('❌ MongoDB Connection Error:', err.message);
      this.connected = false;
      throw new Error(`Wallet DB unavailable: ${err.message}`);
    }
  }

  async disconnect() {
    if (!this.connected) return;
    try {
      await mongoose.connection.close();
      this.connected = false;
      console.log('🔌 Wallet DB: Disconnected');
    } catch (err) {
      console.warn('⚠️ Error closing DB connection:', err.message);
    }
  }

  async getWallet(userId) {
    if (!userId || typeof userId !== 'string') throw new Error('Valid userId required');
    let wallet = await Wallet.findOne({ userId }).lean().exec();
    if (!wallet) {
      wallet = await Wallet.create({ userId });
      console.log(`🆕 New wallet: ${userId}`);
      wallet = await Wallet.findOne({ userId }).lean().exec();
    }
    return wallet;
  }

  async getBalance(userId) {
    const wallet = await this.getWallet(userId);
    return wallet.balance ?? 0;
  }

  async addMoola(userId, amount, description = 'System Credit', meta = {}) {
    if (!userId) throw new Error('userId required');
    const val = Number(amount);
    if (!Number.isFinite(val) || val <= 0) throw new Error(`Invalid amount: ${amount}`);

    const updated = await Wallet.findOneAndUpdate(
      { userId },
      {
        $inc: { balance: val, totalEarned: val },
        $set: { lastTransaction: new Date(), updatedAt: new Date() }
      },
      { new: true, upsert: true, runValidators: true }
    ).exec();

    await Transaction.create({
      userId, type: 'credit', amount: val, description, metadata: meta
    });

    console.log(`💰 +${val} Moola → ${userId} | Balance: ${updated.balance}`);
    return updated.balance;
  }

  async spendMoola(userId, amount, description = 'Payment', meta = {}) {
    if (!userId) throw new Error('userId required');
    const val = Number(amount);
    if (!Number.isFinite(val) || val <= 0) throw new Error(`Invalid amount: ${amount}`);

    const updated = await Wallet.findOneAndUpdate(
      { userId, balance: { $gte: val } },
      {
        $inc: { balance: -val, totalSpent: val },
        $set: { lastTransaction: new Date(), updatedAt: new Date() }
      },
      { new: true, runValidators: true }
    ).exec();

    if (!updated) {
      const current = await this.getBalance(userId);
      throw new Error(`Insufficient balance: need ${val}, have ${current}`);
    }

    await Transaction.create({
      userId, type: 'debit', amount: val, description, metadata: meta
    });

    console.log(`💸 -${val} Moola ← ${userId} | Balance: ${updated.balance}`);
    return updated.balance;
  }

  async transferMoola(fromUserId, toUserId, amount, description = 'Moola Transfer', meta = {}) {
    if (!fromUserId || !toUserId) throw new Error('Both sender & receiver required');
    if (fromUserId === toUserId) throw new Error('Cannot transfer to yourself');
    const val = Number(amount);
    if (!Number.isFinite(val) || val <= 0) throw new Error(`Invalid amount: ${amount}`);

    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const sender = await Wallet.findOneAndUpdate(
        { userId: fromUserId, balance: { $gte: val } },
        {
          $inc: { balance: -val, totalSpent: val },
          $set: { lastTransaction: new Date(), updatedAt: new Date() }
        },
        { new: true, session, runValidators: true }
      ).exec();
      if (!sender) throw new Error(`Sender has insufficient balance`);

      await Wallet.findOneAndUpdate(
        { userId: toUserId },
        {
          $inc: { balance: val, totalEarned: val },
          $set: { lastTransaction: new Date(), updatedAt: new Date() }
        },
        { new: true, upsert: true, session, runValidators: true }
      ).exec();

      await Transaction.create([
        { userId: fromUserId, type: 'transfer', amount: -val, description: `→ ${toUserId}: ${description}`, metadata: meta },
        { userId: toUserId, type: 'transfer', amount: val, description: `← ${fromUserId}: ${description}`, metadata: meta }
      ], { session });

      await session.commitTransaction();
      console.log(`🔄 Transfer: ${fromUserId} → ${toUserId} : ${val} Moola`);
      return { success: true, amount: val, fromBalance: sender.balance };
    } catch (err) {
      await session.abortTransaction();
      console.error(`❌ Transfer failed: ${err.message}`);
      throw new Error(`Transfer failed: ${err.message}`);
    } finally {
      session.endSession();
    }
  }

  async getTransactionHistory(userId, limit = 50, skip = 0, type = null) {
    if (!userId) throw new Error('userId required');
    const query = { userId };
    if (type) query.type = type;
    return Transaction.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Math.min(limit, 200))
      .lean()
      .exec();
  }

  async getWalletStats(userId) {
    const wallet = await this.getWallet(userId);
    return {
      userId: wallet.userId,
      balance: wallet.balance,
      totalEarned: wallet.totalEarned,
      totalSpent: wallet.totalSpent,
      net: (wallet.totalEarned || 0) - (wallet.totalSpent || 0),
      lastTransaction: wallet.lastTransaction,
      createdAt: wallet.createdAt,
      updatedAt: wallet.updatedAt
    };
  }

  async getAllWallets(limit = 100, skip = 0, minBalance = null) {
    const query = minBalance ? { balance: { $gte: minBalance } } : {};
    return Wallet.find(query)
      .sort({ balance: -1 })
      .skip(skip)
      .limit(Math.min(limit, 500))
      .lean()
      .exec();
  }

  async deleteWallet(userId) {
    if (!userId) throw new Error('userId required');
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      await Wallet.deleteOne({ userId }, { session });
      await Transaction.deleteMany({ userId }, { session });
      await session.commitTransaction();
      console.log(`🗑️ Deleted wallet: ${userId}`);
      return true;
    } catch (err) {
      await session.abortTransaction();
      throw err;
    } finally {
      session.endSession();
    }
  }

  async convertMoolaToCash(userId, amount, cashValue, fee, userReceives, currency = 'ZAR', method = 'EFT') {
    const val = Number(amount);
    if (!Number.isFinite(val) || val <= 0) throw new Error(`Invalid amount: ${amount}`);
    const balance = await this.spendMoola(userId, val, `Cash-out: ${val} Moola → ${currency} ${cashValue} via ${method}`, { cashValue, fee, userReceives, currency, method });
    return { success: true, moolaBurned: val, cashValue, fee, userReceives, currency, method, newBalance: balance };
  }
}

module.exports = { MongoWalletManager, Wallet, Transaction };
