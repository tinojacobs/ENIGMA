// ==============================================
// ✅ ENIGMA Driver Profile — Mongoose Schema
// 👤 Identity • Vehicle • Banking • Wallet • Stats • Status • Settings
// Fully Hardened • Secure • Production‑Ready • South Africa! 🇿🇦
// ==============================================

const mongoose = require('mongoose');
const { Schema } = mongoose;

const driverProfileSchema = new Schema({
  // ==========================================
  // 🔐 IDENTITY & CONTACT
  // ==========================================
  driverId: {
    type: String,
    required: [true, 'Driver ID is required'],
    unique: true,
    index: true,
    trim: true
  },

  name: {
    type: String,
    required: [true, 'Full name is required'],
    trim: true,
    maxlength: [100, 'Name cannot exceed 100 characters']
  },

  phone: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true,
    match: [/^(\+27|0)[6-8][0-9]{8}$/, 'Please enter a valid South African mobile number']
  },

  email: {
    type: String,
    trim: true,
    lowercase: true,
    default: null,
    match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email address']
  },

  idNumber: {
    type: String,
    trim: true,
    length: 13,
    default: null,
    select: false // Hidden from default queries for privacy
  },

  profilePhoto: {
    type: String,
    default: null
  },

  // ==========================================
  // 🚗 VEHICLE DETAILS — South African Spec
  // ==========================================
  vehicle: {
    make: { type: String, trim: true, default: null },
    model: { type: String, trim: true, default: null },
    year: { type: Number, min: 1990, max: new Date().getFullYear() + 1, default: null },
    color: { type: String, trim: true, default: null },
    plate: {
      type: String,
      trim: true,
      uppercase: true,
      match: [/^[A-Z0-9 ]+$/, 'Invalid license plate format'],
      default: null
    },
    vehicleType: {
      type: String,
      enum: ['standard', 'luxury', 'suv', 'van', 'eco', 'bike'],
      default: 'standard'
    },
    capacity: { type: Number, min: 1, max: 8, default: 4 },
    registered: { type: Boolean, default: false }
  },

  // ==========================================
  // 🏦 BANKING & PAYOUT INFO — South African
  // ==========================================
  banking: {
    bankName: { type: String, trim: true, default: null },
    accountHolder: { type: String, trim: true, default: null },
    accountNumber: { type: String, trim: true, default: null, select: false },
    branchCode: { type: String, trim: true, default: null },
    accountType: { type: String, enum: ['cheque', 'savings', 'transmission'], default: 'cheque' },
    payoutMethod: {
      type: String,
      enum: ['auto', 'manual', 'EFT', 'airtime', 'moola', 'voucher'],
      default: 'auto'
    }
  },

  // ==========================================
  // 💰 WALLET & FINANCIAL BALANCES
  // ==========================================
  earnings: {
    type: Number,
    default: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100,
    min: [0, 'Balance cannot be negative']
  },

    pendingPayouts: {
    type: Number,
    default: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100,
    min: [0, 'Pending balance cannot be negative']
  },

    moolaBalance: {
    type: Number,
    default: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100,
    min: [0, 'Moola balance cannot be negative']
  },

    totalEarningsAllTime: {
    type: Number,
    default: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100
  },

    totalPaidOut: {
    type: Number,
    default: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100
  },

  // ==========================================
  // ⭐ RATINGS, BADGES & REPUTATION
  // ==========================================
  rating: {
    type: Number,
    default: 4.8,
    min: [1, 'Rating cannot be below 1.0'],
    max: [5, 'Rating cannot exceed 5.0'],
    get: v => Math.round(v * 10) / 10,
    set: v => Math.round(Number(v) * 10) / 10
  },

    ratingCount: {
    type: Number,
    default: 0,
    min: 0
  },

    badges: [{
    type: String,
    trim: true,
    enum: [
      'newcomer', '5trips', '25trips', '50trips', '100trips', '500trips',
      '5star', 'excellent', 'reliable', 'nightowl', 'weekendwarrior',
      'topearner', 'fastresponder', 'safeDriver', 'premium'
    ]
  }],

  // ==========================================
  // 📊 STATISTICS & METRICS
  // ==========================================
  totalTrips: { type: Number, default: 0, min: 0 },
    totalDistance: {
    type: Number, default: 0, min: 0,
    get: v => Math.round(v * 10) / 10,
    set: v => Math.round(Number(v) * 10) / 10
  },
    totalHoursOnline: {
    type: Number, default: 0, min: 0,
    get: v => Math.round(v * 10) / 10,
    set: v => Math.round(Number(v) * 10) / 10
  },
    totalCancelled: { type: Number, default: 0, min: 0 },
    acceptanceRate: { type: Number, default: 95, min: 0, max: 100 },
    cancellationRate: { type: Number, default: 5, min: 0, max: 100 },

  // ==========================================
  // 🟢 ONLINE STATUS
  // ==========================================
  status: {
    type: String,
    enum: {
      values: ['offline', 'online', 'onTrip', 'paused', 'suspended'],
      message: 'Status must be: offline, online, onTrip, paused or suspended'
    },
    default: 'offline',
    index: true
  },

    isActive: { type: Boolean, default: true, index: true },
    isVerified: { type: Boolean, default: false },
    lastActive: { type: Date, default: Date.now, index: true },
    lastLocation: {
      lat: { type: Number, default: null },
      lng: { type: Number, default: null },
      updatedAt: { type: Date, default: null }
    },

  // ==========================================
  // 🎯 GOALS & SETTINGS
  // ==========================================
    weeklyTarget: { type: Number, default: 15, min: 1 },
    earningsTarget: { type: Number, default: 3000, min: 0 },
    autoPayoutEnabled: { type: Boolean, default: true },
    payoutThreshold: {
      type: Number, default: 500, min: 10,
      get: v => Math.round(v * 100) / 100,
      set: v => Math.round(Number(v) * 100) / 100
    },
    preferences: {
      rideTypes: [{ type: String }],
      maxDistance: { type: Number, default: 15 },
      nightMode: { type: Boolean, default: false },
      notifications: {
        push: { type: Boolean, default: true },
        sms: { type: Boolean, default: true },
        email: { type: Boolean, default: true }
      }
    }

}, {
  timestamps: true,
  toJSON: { getters: true, virtuals: true },
  toObject: { getters: true, virtuals: true }
});

// ==========================================
// 📊 INDEXES — Optimize Queries
// ==========================================
driverProfileSchema.index({ status: 1, isActive: 1, lastActive: -1 });
driverProfileSchema.index({ earnings: -1 });
driverProfileSchema.index({ rating: -1 });
driverProfileSchema.index({ totalTrips: -1 });

// ==========================================
// 🔒 VIRTUAL FIELDS — Computed Properties
// ==========================================
driverProfileSchema.virtual('availableBalance').get(function () {
  return this.earnings;
});

driverProfileSchema.virtual('netWorth').get(function () {
  return this.earnings + this.moolaBalance;
});

driverProfileSchema.virtual('isAvailable').get(function () {
  return this.isActive && this.status === 'online';
});

// ==========================================
// 🛠️ INSTANCE METHODS — Business Logic
// ==========================================

// Add earnings to balance + update totals
driverProfileSchema.methods.addEarnings = function (amount) {
  const value = Number(amount) || 0;
  if (value <= 0) return this;

  this.earnings = this.earnings + value;
  this.totalEarningsAllTime = this.totalEarningsAllTime + value;
  return this;
};

// Deduct balance when payout created
driverProfileSchema.methods.deductForPayout = function (amount) {
  const value = Number(amount) || 0;
  if (value <= 0 || this.earnings < value) return null;

  this.earnings = this.earnings - value;
  this.pendingPayouts = this.pendingPayouts + value;
  return this;
};

// Confirm payout completed — move pending → paid
driverProfileSchema.methods.confirmPayoutPaid = function (amount) {
  const value = Number(amount) || 0;
  if (value <= 0) return this;

  this.pendingPayouts = Math.max(0, this.pendingPayouts - value);
  this.totalPaidOut = this.totalPaidOut + value;
  return this;
};

// Add trip stats
driverProfileSchema.methods.incrementTripStats = function (distanceKm = 0) {
  this.totalTrips += 1;
  this.totalDistance = this.totalDistance + (Number(distanceKm) || 0);
  this.lastActive = new Date();
  return this;
};

// Update rating
driverProfileSchema.methods.updateRating = function (newRating) {
  const r = Number(newRating);
  if (!r || r < 1 || r > 5) return this;

  const totalScore = this.rating * this.ratingCount;
  this.ratingCount += 1;
  this.rating = (totalScore + r) / this.ratingCount;
  return this;
};

// Award badge if not already earned
driverProfileSchema.methods.awardBadge = function (badgeId) {
  if (!badgeId || this.badges.includes(badgeId)) return false;
  this.badges.push(badgeId);
  return true;
};

// ==========================================
// 📊 STATIC METHODS — Query Helpers
// ==========================================
driverProfileSchema.statics.findActiveDrivers = function (limit = 200) {
  return this.find({ isActive: true, status: { $in: ['online', 'onTrip'] } })
    .sort({ lastActive: -1 })
    .limit(limit)
    .exec();
};

driverProfileSchema.statics.findByStatus = function (status, limit = 100) {
  return this.find({ status, isActive: true })
    .sort({ lastActive: -1 })
    .limit(limit)
    .exec();
};

driverProfileSchema.statics.getTopEarners = function (limit = 10) {
  return this.find({ isActive: true })
    .sort({ totalEarningsAllTime: -1 })
    .limit(limit)
    .exec();
};

// ==========================================
// 🚀 EXPORT MODEL
// ==========================================
module.exports = mongoose.model('DriverProfile', driverProfileSchema);
