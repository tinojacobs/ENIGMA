// ==============================================
// ✅ ENIGMA Trip History — Mongoose Schema
// 🚗 Rides • Locations • Fare • Payment • Status • Driver • Rider
// Fully Hardened • Secure • Production‑Ready • South Africa! 🇿🇦
// ==============================================

const mongoose = require('mongoose');
const { Schema } = mongoose;

const tripHistorySchema = new Schema({
  // ==========================================
  // 🔑 IDENTITIES & REFERENCES
  // ==========================================
  tripId: {
    type: String,
    required: [true, 'Trip ID is required'],
    unique: true,
    index: true,
    trim: true
  },

  riderId: {
    type: String,
    required: [true, 'Rider ID is required'],
    index: true,
    trim: true
  },

  driverId: {
    type: String,
    required: [true, 'Driver ID is required'],
    index: true,
    trim: true
  },

  // ==========================================
  // 📍 LOCATIONS — Pickup & Dropoff
  // ==========================================
  pickup: {
    address: { type: String, default: null, trim: true },
    lat: {
      type: Number,
      required: [true, 'Pickup latitude is required'],
      min: -90, max: 90
    },
    lng: {
      type: Number,
      required: [true, 'Pickup longitude is required'],
      min: -180, max: 180
    }
  },

  dropoff: {
    address: { type: String, default: null, trim: true },
    lat: {
      type: Number,
      required: [true, 'Dropoff latitude is required'],
      min: -90, max: 90
    },
    lng: {
      type: Number,
      required: [true, 'Dropoff longitude is required'],
      min: -180, max: 180
    }
  },

  waypoints: [{
    lat: Number,
    lng: Number,
    address: String,
    sequence: Number
  }],

  // ==========================================
  // 💰 FARE & FINANCIALS — South African Rands
  // ==========================================
  fare: {
    type: Number,
    required: [true, 'Trip fare is required'],
    min: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100
  },

  commission: {
    type: Number,
    required: true,
    min: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100
  },

  payoutAmount: {
    type: Number,
    required: true,
    min: 0,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(Number(v) * 100) / 100
  },

  paymentMethod: {
    type: String,
    enum: {
      values: ['card', 'airtime', 'voucher', 'moola', 'cash', 'EFT'],
      message: 'Method must be: card, airtime, voucher, moola, cash, or EFT'
    },
    required: [true, 'Payment method is required'],
    trim: true
  },

  transactionRef: { type: String, default: null },
  fareBreakdown: {
    baseFare: { type: Number, default: 0 },
    distanceFare: { type: Number, default: 0 },
    timeFare: { type: Number, default: 0 },
    surgeMultiplier: { type: Number, default: 1.0 },
    vehicleType: { type: String, default: 'standard' },
    minimumFareApplied: { type: Boolean, default: false }
  },

  // ==========================================
  // 📏 TRIP METRICS
  // ==========================================
  distanceKm: {
    type: Number,
    required: true,
    min: 0,
    get: v => Math.round(v * 10) / 10,
    set: v => Math.round(Number(v) * 10) / 10
  },

  durationMin: {
    type: Number,
    default: 0,
    min: 0
  },

  vehicleType: {
    type: String,
    enum: ['standard', 'eco', 'suv', 'luxury', 'van', 'bike'],
    default: 'standard'
  },

  // ==========================================
  // 🔄 STATUS LIFECYCLE
  // ==========================================
  status: {
    type: String,
    enum: {
      values: ['requested', 'accepted', 'enroute', 'arrived', 'inProgress',
               'completed', 'cancelledByRider', 'cancelledByDriver', 'noShow'],
      message: 'Invalid trip status'
    },
    default: 'requested',
    index: true
  },

  cancelledBy: { type: String, enum: ['rider', 'driver', 'system', null], default: null },
  cancellationReason: { type: String, trim: true, default: null },

  // ==========================================
  // ⭐ RATINGS & FEEDBACK
  // ==========================================
  rating: {
    type: Number,
    min: 1,
    max: 5,
    default: null
  },

  feedback: { type: String, trim: true, maxlength: 1000, default: '' },

  // ==========================================
  // 📅 TIMELINE — Full Lifecycle Timestamps
  // ==========================================
  timestamp: { type: Date, default: Date.now, index: true },
  requestedAt: { type: Date, default: Date.now },
  acceptedAt: { type: Date, default: null },
  startedAt: { type: Date, default: null },
  completedAt: { type: Date, default: null },
  cancelledAt: { type: Date, default: null }

}, {
  timestamps: true,
  toJSON: { getters: true },
  toObject: { getters: true }
});

// ==========================================
// 📊 INDEXES — Optimize Common Queries
// ==========================================
tripHistorySchema.index({ driverId: 1, timestamp: -1 });
tripHistorySchema.index({ riderId: 1, timestamp: -1 });
tripHistorySchema.index({ status: 1, timestamp: -1 });
tripHistorySchema.index({ driverId: 1, status: 1, timestamp: -1 });
tripHistorySchema.index({ riderId: 1, status: 1, timestamp: -1 });
tripHistorySchema.index({ fare: -1 });

// ==========================================
// 🔧 PRE‑SAVE HOOKS — Auto‑Set Timestamps
// ==========================================
tripHistorySchema.pre('save', function(next) {
  if (this.isModified('status')) {
    const now = new Date();
    switch (this.status) {
      case 'accepted': this.acceptedAt = this.acceptedAt || now; break;
      case 'inProgress': this.startedAt = this.startedAt || now; break;
      case 'completed': this.completedAt = this.completedAt || now; break;
      case 'cancelledByRider':
      case 'cancelledByDriver':
      case 'noShow':
        this.cancelledAt = this.cancelledAt || now;
        break;
    }
  }
  next();
});

// ==========================================
// 🛠️ INSTANCE METHODS — Trip Operations
// ==========================================

tripHistorySchema.methods.acceptTrip = function() {
  if (this.status !== 'requested') return false;
  this.status = 'accepted';
  this.acceptedAt = new Date();
  return this.save();
};

tripHistorySchema.methods.startTrip = function() {
  if (!['accepted', 'arrived', 'enroute'].includes(this.status)) return false;
  this.status = 'inProgress';
  this.startedAt = new Date();
  return this.save();
};

tripHistorySchema.methods.completeTrip = function(finalDistanceKm, finalDurationMin) {
  if (this.status !== 'inProgress') return false;
  this.status = 'completed';
  this.completedAt = new Date();
  if (finalDistanceKm !== undefined) this.distanceKm = finalDistanceKm;
  if (finalDurationMin !== undefined) this.durationMin = finalDurationMin;
  return this.save();
};

tripHistorySchema.methods.cancelTrip = function(cancelledBy, reason = '') {
  if (this.status === 'completed') return false;
  this.status = cancelledBy === 'rider' ? 'cancelledByRider' :
                cancelledBy === 'driver' ? 'cancelledByDriver' : 'cancelledBySystem';
  this.cancelledBy = cancelledBy;
  this.cancellationReason = reason;
  this.cancelledAt = new Date();
  return this.save();
};

tripHistorySchema.methods.addRating = function(stars, feedbackText = '') {
  if (this.status !== 'completed') return false;
  this.rating = stars;
  this.feedback = feedbackText;
  return this.save();
};

// ==========================================
// 📊 STATIC METHODS — Query Helpers
// ==========================================

tripHistorySchema.statics.findByDriver = function(driverId, limit = 50) {
  return this.find({ driverId })
    .sort({ timestamp: -1 })
    .limit(limit)
    .exec();
};

tripHistorySchema.statics.findByRider = function(riderId, limit = 50) {
  return this.find({ riderId })
    .sort({ timestamp: -1 })
    .limit(limit)
    .exec();
};

tripHistorySchema.statics.findCompletedByDriver = function(driverId, limit = 100) {
  return this.find({ driverId, status: 'completed' })
    .sort({ timestamp: -1 })
    .limit(limit)
    .exec();
};

tripHistorySchema.statics.getTotalEarnings = async function(driverId) {
  const result = await this.aggregate([
    { $match: { driverId, status: 'completed' } },
    { $group: { _id: '$driverId', total: { $sum: '$payoutAmount' }, count: { $count: {} } } }
  ]);
  return result[0] || { total: 0, count: 0 };
};

tripHistorySchema.statics.getTotalDistance = async function(driverId) {
  const result = await this.aggregate([
    { $match: { driverId, status: 'completed' } },
    { $group: { _id: '$driverId', totalKm: { $sum: '$distanceKm' } } }
  ]);
  return result[0]?.totalKm || 0;
};

// ==========================================
// 🚀 EXPORT MODEL
// ==========================================
module.exports = mongoose.model('TripHistory', tripHistorySchema);
