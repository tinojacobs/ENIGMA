// ==============================================
// ✅ ENIGMA Trip History API — Express Router
// 🚗 Get Trips • Filter by Day/Week/Month • Earnings Breakdown • Stats Aggregation
// Fully Hardened • Secure • Production‑Ready • South Africa! 🇿🇦
// ==============================================

const express = require('express');
const router = express.Router();
const TripHistory = require('../models/tripHistory');

// ==============================================
// 🛡️ VALIDATION HELPERS
// ==============================================
const ALLOWED_FILTERS = ['day', 'week', 'month', 'all'];
const DEFAULT_LIMIT = 100;
const MAX_LIMIT = 500;

function buildDateRange(filter) {
  if (!filter || filter === 'all') return null;

  const now = new Date();
  now.setHours(23, 59, 59, 999);
  let start;

  switch (filter) {
    case 'day':
      start = new Date(now);
      start.setHours(0, 0, 0, 0);
      break;
    case 'week':
      start = new Date(now);
      start.setDate(start.getDate() - 7);
      start.setHours(0, 0, 0, 0);
      break;
    case 'month':
      start = new Date(now);
      start.setMonth(start.getMonth() - 1);
      start.setHours(0, 0, 0, 0);
      break;
    default:
      return null;
  }

  return { $gte: start, $lte: now };
}

function formatTripResponse(trip) {
  return {
    tripId: trip.tripId,
    driverId: trip.driverId,
    passengerId: trip.passengerId || null,
    pickup: trip.pickup || trip.from || null,
    dropoff: trip.dropoff || trip.to || null,
    fare: Number(trip.fare) || 0,
    commission: Number(trip.commission) || 0,
    payoutAmount: Number(trip.payoutAmount) || (Number(trip.fare) - Number(trip.commission)),
    paymentMethod: trip.paymentMethod || 'unknown',
    status: trip.status || 'completed',
    distanceKm: trip.distanceKm || 0,
    durationMin: trip.durationMin || 0,
    timestamp: trip.timestamp,
    createdAt: trip.createdAt || trip.timestamp
  };
}

// ==============================================
// 📋 GET /api/driver/:driverId/trips
// Returns trip list with full financial breakdown
// Query params: ?filter=day|week|month|all&limit=50&page=1
// ==============================================
router.get('/:driverId/trips', async (req, res) => {
  try {
    const { driverId } = req.params;
    const { filter = 'week', limit: limitQuery, page = 1 } = req.query;

    // 🛡️ Input Validation
    if (!driverId || driverId.trim().length < 2) {
      return res.status(400).json({ error: 'Valid driverId is required' });
    }

    const normalizedFilter = ALLOWED_FILTERS.includes(filter) ? filter : 'week';
    const limit = Math.min(Math.max(parseInt(limitQuery, 10) || DEFAULT_LIMIT, 1), MAX_LIMIT);
    const skip = (Math.max(parseInt(page, 10) || 1, 1) - 1) * limit;

    // 🔍 Build Query
    const query = {
      driverId: driverId.trim(),
      status: 'completed'
    };

    const dateRange = buildDateRange(normalizedFilter);
    if (dateRange) query.timestamp = dateRange;

    // 📦 Execute Query
    const [trips, total] = await Promise.all([
      TripHistory.find(query)
        .sort({ timestamp: -1, _id: -1 })
        .skip(skip)
        .limit(limit)
        .lean()
        .exec(),
      TripHistory.countDocuments(query)
    ]);

    // 📤 Format Response
    const formattedTrips = trips.map(formatTripResponse);

    return res.json({
      success: true,
      data: formattedTrips,
      pagination: {
        page: parseInt(page, 10),
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        returned: formattedTrips.length
      },
      filter: normalizedFilter,
      counts: {
        totalTrips: formattedTrips.length,
        totalFare: formattedTrips.reduce((sum, t) => sum + t.fare, 0),
        totalCommission: formattedTrips.reduce((sum, t) => sum + t.commission, 0),
        totalPayout: formattedTrips.reduce((sum, t) => sum + t.payoutAmount, 0)
      }
    });

  } catch (err) {
    console.error('❌ Trip history fetch error:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to load trip history',
      message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
});

// ==============================================
// 📊 GET /api/driver/:driverId/trips/summary
// Returns aggregated earnings & trip stats
// ==============================================
router.get('/:driverId/trips/summary', async (req, res) => {
  try {
    const { driverId } = req.params;
    const { filter = 'week' } = req.query;

    if (!driverId || driverId.trim().length < 2) {
      return res.status(400).json({ error: 'Valid driverId is required' });
    }

    const normalizedFilter = ALLOWED_FILTERS.includes(filter) ? filter : 'week';
    const dateRange = buildDateRange(normalizedFilter);

    const query = {
      driverId: driverId.trim(),
      status: 'completed'
    };
    if (dateRange) query.timestamp = dateRange;

    const result = await TripHistory.aggregate([
      { $match: query },
      {
        $group: {
          _id: '$driverId',
          totalTrips: { $count: {} },
          totalFare: { $sum: '$fare' },
          totalCommission: { $sum: '$commission' },
          totalPayout: { $sum: { $subtract: ['$fare', '$commission'] } },
          totalDistance: { $sum: '$distanceKm' },
          avgFare: { $avg: '$fare' },
          firstTrip: { $min: '$timestamp' },
          lastTrip: { $max: '$timestamp' }
        }
      }
    ]);

    const stats = result[0] || {
      totalTrips: 0,
      totalFare: 0,
      totalCommission: 0,
      totalPayout: 0,
      totalDistance: 0,
      avgFare: 0
    };

    return res.json({
      success: true,
      filter: normalizedFilter,
      data: {
        totalTrips: stats.totalTrips,
        totalFare: Math.round(stats.totalFare * 100) / 100,
        totalCommission: Math.round(stats.totalCommission * 100) / 100,
        totalPayout: Math.round(stats.totalPayout * 100) / 100,
        totalDistanceKm: Math.round(stats.totalDistance * 10) / 10,
        avgFare: Math.round(stats.avgFare * 100) / 100,
        firstTrip: stats.firstTrip,
        lastTrip: stats.lastTrip
      }
    });

  } catch (err) {
    console.error('❌ Trip summary error:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to calculate trip summary',
      message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
});

// ==============================================
// 🔍 GET /api/driver/:driverId/trips/:tripId
// Get single trip by ID
// ==============================================
router.get('/:driverId/trips/:tripId', async (req, res) => {
  try {
    const { driverId, tripId } = req.params;

    if (!driverId || !tripId) {
      return res.status(400).json({ error: 'driverId and tripId are required' });
    }

    const trip = await TripHistory.findOne({ driverId, tripId }).lean();

    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    return res.json({
      success: true,
      data: formatTripResponse(trip)
    });

  } catch (err) {
    console.error('❌ Single trip fetch error:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to load trip details',
      message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
});

module.exports = router;
