// ==============================================
// ✅ ENIGMA Payout Model — Mongoose Schema
// 💰 Driver Payouts • Withdrawals • Settlements • Transactions
// Fully Hardened • Production‑Ready • South Africa Methods! 🇿🇦
// ==============================================

const mongoose = require('mongoose');
const { Schema } = mongoose;

const payoutSchema = new Schema({
  // --- Driver Identity ---
  driverId: {
    type: String,
    required: [true, 'Driver ID is required'],
    index: true
  },

  // --- Financial Details ---
  amount: {
    type: Number,
    required: [true, 'Payout amount is required'],
    min: [10, 'Minimum payout is R10'],
    get: v => Math.round(v * 100) / 100,  // Store with 2 decimal places
    set: v => Math.round(v * 100) / 100
  },

  // --- Payout Method — ENIGMA Supported Options ---
  method: {
    type: String,
    enum: {
      values: ['airtime', 'EFT', 'voucher', 'moola'],
      message: 'Method must be: airtime, EFT, voucher, or moola'
    },
    required: [true, 'Payout method is required'],
    lowercase: true,
    trim: true
  },

  // --- Payout Status Lifecycle ---
  status: {
    type: String,
    enum: ['pending', 'processing', 'approved', 'paid', 'failed', 'cancelled', 'refunded'],
    default: 'pending',
    index: true
  },

  // --- Reference & Audit Fields ---
  reference: {
    type: String,
    unique: true,
    sparse: true,
    index: true
  },

  transactionRef: {
    type: String,
    default: null
  },

  // --- Method‑Specific Details ---
  methodDetails: {
    provider: { type: String, default: null },   // e.g. 'Vodacom', 'FNB', 'Standard Bank'
    accountNumber: { type: String, default: null }, // Masked/partial account number
    voucherCode: { type: String, default: null },   // Generated voucher code if applicable
    phoneNumber: { type: String, default: null },   // For airtime top‑ups
    convertedToMoola: { type: Boolean, default: false },
    exchangeRate: { type: Number, default: null }    // If converted between ZAR ↔ Moola
  },

  // --- Balance Accounting ---
  balanceBefore: {
    type: Number,
    required: true,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(v * 100) / 100
  },

  balanceAfter: {
    type: Number,
    required: true,
    get: v => Math.round(v * 100) / 100,
    set: v => Math.round(v * 100) / 100
  },

  // --- Admin & Audit ---
  notes: {
    type: String,
    default: '',
    trim: true,
    maxlength: [500, 'Notes cannot exceed 500 characters']
  },

  processedBy: {
    type: String,
    default: 'system' // 'system' or admin userId
  },

  processedAt: {
    type: Date,
    default: null
  },

  // --- Timestamps ---
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },

  createdAt: {
    type: Date,
    default: Date.now,
    immutable: true
  },

  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  toJSON: { getters: true },
  toObject: { getters: true }
});

// ==============================================
// 📊 INDEXES — Optimize Common Queries
// ==============================================
payoutSchema.index({ driverId: 1, timestamp: -1 });
payoutSchema.index({ driverId: 1, status: 1, timestamp: -1 });
payoutSchema.index({ status: 1, timestamp: -1 });
payoutSchema.index({ method: 1, timestamp: -1 });

// ==============================================
// 🔧 PRE‑SAVE HOOKS — Auto‑Generate Fields
// ==============================================
payoutSchema.pre('save', function(next) {
  // Auto‑generate unique reference if not set: PYT-[DRIVER]-[TIMESTAMP]-[RANDOM]
  if (!this.reference) {
    const timestamp = Date.now().toString().slice(-8);
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    this.reference = `PYT-${this.driverId}-${timestamp}-${random}`;
  }

  // Auto‑update updatedAt on every save
  this.updatedAt = new Date();

  // Auto‑set processedAt when status changes to paid/approved/processed
  if ((this.isModified('status') && ['paid', 'approved', 'processing'].includes(this.status)) && !this.processedAt) {
    this.processedAt = new Date();
  }

  next();
});

// ==============================================
// 🛠️ INSTANCE METHODS — Helper Operations
// ==============================================

// Mark payout as paid
payoutSchema.methods.markAsPaid = function(transactionRef = null) {
  this.status = 'paid';
  this.processedAt = new Date();
  if (transactionRef) this.transactionRef = transactionRef;
  return this.save();
};

// Mark payout as failed with reason
payoutSchema.methods.markAsFailed = function(reason = '') {
  this.status = 'failed';
  this.notes = reason ? `${this.notes ? this.notes + ' | ' : ''}FAILED: ${reason}` : 'FAILED';
  return this.save();
};

// Approve payout
payoutSchema.methods.approve = function(approverId = 'system') {
  this.status = 'approved';
  this.processedBy = approverId;
  return this.save();
};

// Cancel payout
payoutSchema.methods.cancel = function(reason = 'Cancelled by user') {
  this.status = 'cancelled';
  this.notes = reason;
  return this.save();
};

// ==============================================
// 📊 STATIC METHODS — Query Helpers
// ==============================================

// Find all payouts for a specific driver
payoutSchema.statics.findByDriver = function(driverId, limit = 50) {
  return this.find({ driverId })
    .sort({ timestamp: -1 })
    .limit(limit)
    .exec();
};

// Find payouts by status
payoutSchema.statics.findByStatus = function(status, limit = 100) {
  return this.find({ status })
    .sort({ timestamp: -1 })
    .limit(limit)
    .exec();
};

// Get total paid amount for a driver
payoutSchema.statics.getTotalPaid = async function(driverId) {
  const result = await this.aggregate([
    { $match: { driverId, status: 'paid' } },
    { $group: { _id: '$driverId', total: { $sum: '$amount' } } }
  ]);
  return result.length > 0 ? result[0].total : 0;
};

// Get pending payouts total
payoutSchema.statics.getPendingTotal = async function(driverId) {
  const result = await this.aggregate([
    { $match: { driverId, status: { $in: ['pending', 'approved', 'processing'] } } },
    { $group: { _id: '$driverId', total: { $sum: '$amount' } } }
  ]);
  return result.length > 0 ? result[0].total : 0;
};

// ==============================================
// 🚀 EXPORT MODEL
// ==============================================
module.exports = mongoose.model('Payout', payoutSchema);
